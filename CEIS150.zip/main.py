# Initialize variables
count = 0
sum_price = 0

# Input full name and minimum price
full_name = input("Enter your full name: ")
min_price = float(input("Enter the minimum price: "))

# Create a list of prices
price_list = [69.5, 95.6, 79.85, 41, 30.65, 55.5, 47.5, 45.3, 32, 97.85, 32.4]

# Process each price in the list
for price in price_list:
    sum_price += price
    if price > min_price:
        count += 1

# Output results
print(f"Hello {full_name}, the minimum price is {min_price:.2f}")
print(f"There are {count} prices greater than the minimum price")
print(f"The total price is {sum_price:.2f}")
